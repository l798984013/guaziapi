package com.mianze.apiexport;

import com.mianze.apiexport.component.ApiSchedulerTask;
import com.mianze.apiexport.component.RedisOperator;
import com.mianze.apiexport.mapper.ApiMapper;
import net.sf.json.JSONObject;

import net.sourceforge.pinyin4j.PinyinHelper;
import net.sourceforge.pinyin4j.format.HanyuPinyinCaseType;
import net.sourceforge.pinyin4j.format.HanyuPinyinOutputFormat;
import net.sourceforge.pinyin4j.format.HanyuPinyinToneType;
import net.sourceforge.pinyin4j.format.exception.BadHanyuPinyinOutputFormatCombination;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.ArrayList;
import java.util.List;

@RunWith(SpringRunner.class)
@SpringBootTest
public class ApiExportApplicationTests {
    @Autowired
    private ApiSchedulerTask apiSchedulerTask;
    @Autowired
    RedisOperator redisOperator ;
    @Autowired
    ApiMapper apiMapper;
    @Test
    public void contextLoads() {
        apiSchedulerTask.apiTask();
    }

    @Test
    public void test1() {
        List<Object> info=new ArrayList<>();
        JSONObject jsonObject=new JSONObject();
        com.alibaba.fastjson.JSONObject ja= new com.alibaba.fastjson.JSONObject();
        ja.put("ab",10);
        Double b=ja.getDoubleValue("ab");
        System.out.println(b);
       /* ja.put("a",10);
        ja.put("b",20);
        info.add(ja);
        jsonObject.put("c",info);
        jsonObject.put("d",10);
        System.out.println(jsonObject);*/
       /* redisOperator.put("test2","我是测试1");
        System.out.println("我取出的是："+redisOperator.get("test1"));
        System.out.println(redisOperator.getList("201904161404"));*/
//        System.out.println("test2\",\"我是测试1");
//        int a= apiMapper.jjdCity("北京");
//        int a= apiMapper.queryDswCityResult("广州");
       /* String a="北京市";
       String b= a.substring(0,a.length()-1);*/
      /* String a=apiMapper.queryDfrzCityPinyin1("北京市");
       if (a.contains("市")){
            a= a.substring(0,a.length()-1);
       }
        System.out.println("结果是"+a);
        String chinese=a;
        StringBuffer pybf = new StringBuffer();
        char[] arr = chinese.toCharArray();
        HanyuPinyinOutputFormat defaultFormat = new HanyuPinyinOutputFormat();
        defaultFormat.setCaseType(HanyuPinyinCaseType.LOWERCASE);
        defaultFormat.setToneType(HanyuPinyinToneType.WITHOUT_TONE);
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] > 128) {
                try {
                    pybf.append(PinyinHelper.toHanyuPinyinStringArray(arr[i], defaultFormat)[0]);
                } catch (BadHanyuPinyinOutputFormatCombination e) {
                    e.printStackTrace();
                }
            } else {
                pybf.append(arr[i]);
            }
        }
        System.out.println(pybf.toString());*/

    }
    @Test
    public void  test2(){

    }
}
