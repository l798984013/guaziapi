package com.mianze.apiexport.pojo;

import java.util.List;

public class LongRequest {

    private String order_no;

    public String getOrder_no() {
        return order_no;
    }

    public void setOrder_no(String order_no) {
        this.order_no = order_no;
    }
}
